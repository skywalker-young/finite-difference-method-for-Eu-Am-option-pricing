function [ema] = EMA(price,n)

for t = 1:length(price)
    for num = 1:length(price(1,:))
        if t <= n
            ema(t,num) = price(t,num);
        else
            ema(t,num) = (price(t,num)*2 + ema(t-1,num)*(n-1)) / (n+1);
        end
    end
end
end