function [rsi_fatcor,rsi] = RSI(price,n_rsi)

price_dif = price(2:end,:) - price(1:end-1,:);
for t = 1:length(price)
    for num = 1:length(price(1,:))
        if t > 1
            if t <= n_rsi
                up_av(t,num) = 0;
                down_av(t,num) = 0;
                rsi(t,num) = 0;
                rsi_fatcor(t,num) = 0;
            else
                up_av(t,num) = mean(price_dif(t-n_rsi-1+find(price_dif(t-n_rsi:t-1,num) > 0),num));
                if length(find(price_dif(t-n_rsi:t-1,num) > 0)) == 0
                    up_av(t,num) = 0;
                end
                down_av(t,num) = abs(mean(price_dif(t-n_rsi-1+find(price_dif(t-n_rsi:t-1,num) < 0),num)));
                if length(find(price_dif(t-n_rsi:t-1,num) < 0)) == 0
                    down_av(t,num) = 0;
                end
                rsi(t,num) = 100 - 100 / (1 + (up_av(t,num) / down_av(t,num)));
                
                if rsi(t,num) < 30
                    rsi_fatcor(t,num) = 1;%��
                elseif rsi(t,num) > 70
                    rsi_fatcor(t,num) = -1;%��
                else
                    rsi_fatcor(t,num) = rsi_fatcor(t-1,num);
                end
            end
        end
    end
end
end