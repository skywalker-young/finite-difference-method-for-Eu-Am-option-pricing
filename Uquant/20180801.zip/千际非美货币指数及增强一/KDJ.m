function [kdj] = KDJ(price,n_kdj)

for t = 1:length(price)
    for num = 1:length(price(1,:))
        if t<=n_kdj
            k(t,num) = 50;
            d(t,num) = 50;
            rsv(t,num) = 0;
            j(t,num) = 3 * k(t,num) - 2 * d(t,num);
            kdj(t,num) = 0;
        else
            rsv(t,num) = ( price(t,num) - min(price(t-n_kdj:t,num)) ) / ( max(price(t-n_kdj:t,num)) - min(price(t-n_kdj:t,num)) ) * 100;
            k(t,num) = 2/3 * k(t-1,num) + 1/3 * rsv(t,num);
            d(t,num) = 2/3 * d(t-1,num) + 1/3 * k(t,num);
            j(t,num) = 3 * k(t,num) - 2 * d(t,num);
            
            if k(t,num) > d(t,num) && k(t-1,num) <= d(t,num)
                kdj(t,num) = 1;%��
            elseif k(t,num) < d(t,num) && k(t-1,num) >= d(t,num)
                kdj(t,num) = -1;%��
            else
                kdj(t,num) = 0;%û�ź��򲻳ֲ�
            end
        end
    end
end
end