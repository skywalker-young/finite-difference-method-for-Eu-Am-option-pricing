function [cmi_factor,cmi] = CMI(price,n_cmi)

for t = 1:length(price)
    for num = 1:length(price(1,:))
        if t < n_cmi
            cmi_factor(t,num) = 0;
        else
            cmi(t,num) = abs(price(t,num) - price(t-n_cmi+1,num)) *100 / (max(price(t-n_cmi+1:t,num)) - min(price(t-n_cmi+1:t,num)));
            
            if cmi(t,num) > 20 %����
                cmi_factor(t,num) = 1;
            else %��
                cmi_factor(t,num) = -1;
            end
        end
    end
end
end